#
import os,sys

print("successful execution of a custom image")